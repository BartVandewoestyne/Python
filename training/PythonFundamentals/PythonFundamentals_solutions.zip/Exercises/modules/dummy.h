#ifndef dummy_H
#define dummy_H

int dummy(int a);
int another_dummy(int a);

#endif // dummy_H
