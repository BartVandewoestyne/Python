
#include "dummy.h"

int dummy(int a)
{
    return a++;
}


int another_dummy(int a)
{
    return a--;
}

