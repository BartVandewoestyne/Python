#!/usr/bin/env python
"""Auto generated test module for: temperature """

import unittest
import temperature #pylint: disable=W0611

class Testtemperature(unittest.TestCase):  #pylint: disable=R0904
    """
    Test class for temperature
    """    def test_c2f(self):"
                """ Testsc2f"""'
                self.assertTrue(False)

    def test_c2k(self):"
                """ Testsc2k"""'
                self.assertTrue(False)

    def test_f2c(self):"
                """ Testsf2c"""'
                self.assertTrue(False)

    def test_f2k(self):"
                """ Testsf2k"""'
                self.assertTrue(False)

    def test_k2c(self):"
                """ Testsk2c"""'
                self.assertTrue(False)

    def test_k2f(self):"
                """ Testsk2f"""'
                self.assertTrue(False)

unittest.main()
