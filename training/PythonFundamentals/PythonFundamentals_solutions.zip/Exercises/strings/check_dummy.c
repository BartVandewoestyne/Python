//Automatically generated code to Check module dummy

#include <stdlib.h>
#include <check.h>
#include "dummy.h"
//------------------------------------------------------------
START_TEST (test_dummy)
{
    ck_abort();
}
END_TEST
//------------------------------------------------------------
START_TEST (test_another_dummy)
{
    ck_abort();
}
END_TEST
//------------------------------------------------------------
Suite* dummy_suite()
{
    Suite* s = suite_create("dummy");
    TCase* core = tcase_create("Core");
    tcase_add_test(core, test_dummy);
    tcase_add_test(core, test_another_dummy);
    suite_add_tcase(s, core);
    return s;
}
//------------------------------------------------------------
int main()
{
    int number_failed;
    Suite *s =dummy_suite();
    SRunner *sr = srunner_create (s);
    srunner_run_all (sr, CK_NORMAL);
    number_failed = srunner_ntests_failed (sr);
    srunner_free (sr);
    return (number_failed == 0) ? EXIT_SUCCESS : EXIT_FAILURE;
}
//------------------------------------------------------------
