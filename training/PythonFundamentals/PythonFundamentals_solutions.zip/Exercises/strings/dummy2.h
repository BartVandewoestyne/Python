#ifndef dummy_H
#define dummy_H

int dummyyyy(int a);
int another_dummyyyy(int a);

#endif // dummy_H
