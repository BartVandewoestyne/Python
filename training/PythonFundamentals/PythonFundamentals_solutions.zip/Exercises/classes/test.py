#!/usr/bin/env python
"""Auto generated test module for: awesome """

#pylint: disable=R0904
#pylint: disable=W0611

import unittest
from awesome import *

class TestAwesomeOutletsBank(unittest.TestCase): 
    """
    Test class for AwesomeOutletsBank
    """
    def test___init__(self):
        """ Tests __init__"""
        self.assertTrue(False)

    def test_get_outlets(self):
        """ Tests get_outlets"""
        self.assertTrue(False)

    def test_set_outlet_state(self):
        """ Tests set_outlet_state"""
        self.assertTrue(False)


class TestPowerOutlet(unittest.TestCase): 
    """
    Test class for PowerOutlet
    """
    def test___init__(self):
        """ Tests __init__"""
        self.assertTrue(False)

    def test_set_state(self):
        """ Tests set_state"""
        self.assertTrue(False)


class TestPowerOutletBank(unittest.TestCase): 
    """
    Test class for PowerOutletBank
    """
    def test_get_outlets(self):
        """ Tests get_outlets"""
        self.assertTrue(False)

    def test_set_outlet_state(self):
        """ Tests set_outlet_state"""
        self.assertTrue(False)


unittest.main()
